jQuery(document).ready(function ($) {
    $('#search-button').click(function () {
        const search = $('#search').val();
        $.ajax({
            url: citiesAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'search_cities',
                search: search,
            },
            success: function (response) {
                $('#cities-table tbody').html('');
                response.forEach(city => {
                    $('#cities-table tbody').append(`
                        <tr>
                            <td>${city.country}</td>
                            <td>${city.post_title}</td>
                            <td>${city.temperature}</td>
                        </tr>
                    `);
                });
            },
        });
    });
});
